using UnityEngine;
using TMPro;

public class Invader : MonoBehaviour
{
    private static int score = 0;
    public TextMeshProUGUI scoreText; // Reference to the TextMeshPro Text component
    public Sprite[] animationSprites;
    public float animationTime = 1.0f;
    public System.Action killed;
    public int scoreIncrement = 1; // Variable to specify the increment value for the score
    private SpriteRenderer _spriteRenderer;
    private int _animationFrame;

    private void Awake()
    {
        _spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void Start()
    {
        InvokeRepeating(nameof(AnimateSprite), this.animationTime, this.animationTime);
    }

    private void AnimateSprite()
    {
        if (this.animationSprites != null && this.animationSprites.Length > 0)
        {
            _animationFrame++;
            if (_animationFrame >= this.animationSprites.Length)
            {
                _animationFrame = 0;
            }
            _spriteRenderer.sprite = this.animationSprites[_animationFrame];
        }
        else
        {
            Debug.LogWarning("animationSprites array is empty or null.");
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.gameObject.layer == LayerMask.NameToLayer("Laser"))
        {
            this.killed.Invoke();
            this.gameObject.SetActive(false);
            score += scoreIncrement; // Increase score by the specified increment value

            // Update the score text content
            if (scoreText != null)
            {
                scoreText.text = "Score: " + score.ToString();
            }

            Debug.Log("Score: " + score);
        }
        else if (other.gameObject.CompareTag("TopBoundary"))
        {
            Debug.Log("Boundary");
            this.killed.Invoke();
            this.gameObject.SetActive(false);
        }
    }
}
